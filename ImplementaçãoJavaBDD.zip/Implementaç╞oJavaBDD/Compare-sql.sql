CREATE DATABASE CompareAqui;

USE CompareAqui;

CREATE TABLE Empresa
(
id INT PRIMARY KEY,
    nome VARCHAR(100),
    CNPJ CHAR(18),
    selo_qualidade BOOLEAN,
    imagem_p TEXT,
    imagem_g TEXT,
    imagem_m TEXT
);

INSERT INTO  Empresa VALUES (1, 'Fiat',  '00.000.000/0001-00', true, 'Empresa/1/p.jpg', 'Empresa/1/m.jpg', 'Empresa/1/g.jpg');
INSERT INTO  Empresa VALUES (2, 'Nike', '00.000.000/0001-00', true, 'Empresa/2/p.jpg', 'Empresa/2/m.jpg', 'Empresa/2/g.jpg');
INSERT INTO  Empresa VALUES (3, 'Adidas', '00.000.000/0001-00', true, 'Empresa/3/p.jpg', 'Empresa/3/m.jpg', 'Empresa/3/g.jpg');
INSERT INTO  Empresa VALUES (4, 'Panasonic', '00.000.000/0001-00', false, 'Empresa/4/p.jpg', 'Empresa/4/m.jpg', 'Empresa/4/g.jpg');
INSERT INTO  Empresa VALUES (5, 'HP', '00.000.000/0001-00', true, 'Empresa/5/p.jpg', 'Empresa/5/m.jpg', 'Empresa/5/g.jpg');
INSERT INTO  Empresa VALUES (6, 'Ford', '00.000.000/0001-00', false, 'Empresa/6/p.jpg', 'Empresa/6/m.jpg', 'Empresa/6/g.jpg');
INSERT INTO  Empresa VALUES (7, 'Jeep', '00.000.000/0001-00', true, 'Empresa/7/p.jpg', 'Empresa/7/m.jpg', 'Empresa/7/g.jpg');
INSERT INTO  Empresa VALUES (8, 'FILA', '00.000.000/0001-00', true, 'Empresa/8/p.jpg', 'Empresa/8/m.jpg', 'Empresa/8/g.jpg');
INSERT INTO  Empresa VALUES (9, 'Microsoft', '00.000.000/0001-00', true, 'Empresa/9/p.jpg', 'Empresa/9/m.jpg', 'Empresa/9/g.jpg');
INSERT INTO  Empresa VALUES (10, 'Ponto do Iphone', '00.000.000/0001-00', false, 'Empresa/10/p.jpg', 'Empresa/10/m.jpg', 'Empresa/10/g.jpg');
INSERT INTO  Empresa VALUES (11, 'Loja do 1 Real','00.000.000/0001-00', true, 'Empresa/11/p.jpg', 'Empresa/11/m.jpg', 'Empresa/11/g.jpg');
INSERT INTO  Empresa VALUES (12, 'Camaflex', '00.000.000/0001-00', false, 'Empresa/12/p.jpg', 'Empresa/12/m.jpg', 'Empresa/12/g.jpg');
INSERT INTO  Empresa VALUES (13, 'Loja do Android', '00.000.000/0001-00', true, 'Empresa/13/p.jpg', 'Empresa/13/m.jpg', 'Empresa/13/g.jpg');
INSERT INTO  Empresa VALUES (14, 'Samsung', '00.000.000/0001-00', true, 'Empresa/14/p.jpg', 'Empresa/14/m.jpg', 'Empresa/14/g.jpg');
INSERT INTO  Empresa VALUES (15, 'Xiome', '00.000.000/0001-00', true, 'Empresa/15/p.jpg', 'Empresa/15/m.jpg', 'Empresa/15/g.jpg');
INSERT INTO  Empresa VALUES (16, 'Casas da Cama', '00.000.000/0001-00', true, 'Empresa/16/p.jpg', 'Empresa/16/m.jpg', 'Empresa/16/g.jpg');
INSERT INTO  Empresa VALUES (17, 'Blusas de Time', '00.000.000/0001-00', true, 'Empresa/17/p.jpg', 'Empresa/17/m.jpg', 'Empresa/17/g.jpg');
INSERT INTO  Empresa VALUES (18, 'Chico dos eletrodomésticos', '00.000.000/0001-00', true, 'Empresa/18/p.jpg', 'Empresa/18/m.jpg', 'Empresa/18/g.jpg');
INSERT INTO  Empresa VALUES (19, 'Ponto Quente', '00.000.000/0001-00', false, 'Empresa/19/p.jpg', 'Empresa/19/m.jpg', 'Empresa/19/g.jpg');
INSERT INTO  Empresa VALUES (20, 'Shoptime', '00.000.000/0001-00', false, 'Empresa/20/p.jpg', 'Empresa/20/m.jpg', 'Empresa/20/g.jpg');
INSERT INTO  Empresa VALUES (21, 'Louis Vuitton','00.000.000/0001-00', true, 'Empresa/21/p.jpg', 'Empresa/21/m.jpg', 'Empresa/21/g.jpg');
INSERT INTO  Empresa VALUES (22, 'Magazineluiza', '00.000.000/0001-00', true, 'Empresa/22/p.jpg', 'Empresa/22/m.jpg', 'Empresa/22/g.jpg');

SELECT * FROM Empresa;